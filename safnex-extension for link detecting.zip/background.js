const API_URL = "https://safnex-nova.onrender.com/api/analyze";

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ enabled: true, autoCheck: true });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "ping") {
    sendResponse({ installed: true, version: chrome.runtime.getManifest().version });
    return false;
  }

  if (request.action === "checkLink") {
    if (!request.url) {
      sendResponse({ success: false, error: "No URL provided." });
      return false;
    }

    checkLinkSafety(request.url)
      .then(result => sendResponse({ success: true, result }))
      .catch(error => sendResponse({ success: false, error: error.message || "Unable to analyze link." }));

    return true;
  }

  sendResponse({ success: false, error: "Unknown action." });
  return false;
});

async function checkLinkSafety(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
      signal: controller.signal
    });

    if (!response.ok) throw new Error(`SAFNEX API returned HTTP ${response.status}`);
    return normalizeResult(await response.json(), url);
  } catch (error) {
    if (error.name === "AbortError") throw new Error("Analysis timed out. Please try again.");
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

function normalizeResult(data, url) {
  const result = data || {};
  let riskScore = Number(result.riskScore ?? result.score ?? result.risk_score ?? 0);
  if (!Number.isFinite(riskScore)) riskScore = 0;
  riskScore = Math.max(0, Math.min(100, Math.round(riskScore)));

  let riskLevel = String(result.riskLevel ?? result.risk_level ?? result.level ?? "").toUpperCase();
  if (!riskLevel) riskLevel = riskScore >= 75 ? "HIGH" : riskScore >= 40 ? "MEDIUM" : "LOW";

  let verdict = result.verdict ?? result.message ?? result.result ?? "";
  if (!verdict) {
    verdict = riskLevel === "HIGH" || riskLevel === "CRITICAL"
      ? "This link shows potentially dangerous indicators."
      : riskLevel === "MEDIUM" || riskLevel === "SUSPICIOUS"
        ? "This link requires caution."
        : "No major suspicious indicators were detected.";
  }

  let reasons = result.reasons ?? result.indicators ?? result.reasons_found ?? [];
  if (!Array.isArray(reasons)) reasons = [String(reasons)];

  return { ...result, url, riskScore, riskLevel, verdict: String(verdict), reasons };
}
