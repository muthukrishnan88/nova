const SAFNEX_REPORT_URL = "https://safnex-nova.onrender.com/link-detector.html";
let isCheckingLink = false;

document.documentElement.setAttribute("data-safnex-installed", "true");

document.addEventListener("click", event => {
  const link = event.target.closest?.("a");
  if (!link?.href) return;

  const href = link.href;
  if (["#", "javascript:", "mailto:", "tel:", "data:"].some(prefix => href.startsWith(prefix))) return;

  let targetURL;
  try { targetURL = new URL(href); } catch { return; }
  if (targetURL.hostname === window.location.hostname) return;
  if (isCheckingLink) return;

  event.preventDefault();
  event.stopPropagation();
  event.stopImmediatePropagation();
  checkLinkBeforeNavigate(href);
}, true);

async function checkLinkBeforeNavigate(url) {
  isCheckingLink = true;
  showSafnexPopup(url, { loading: true });
  try {
    const response = await sendCheckRequest(url);
    showSafnexPopup(url, response?.success ? (response.result || {}) : { error: true, errorMessage: response?.error || "Unable to analyze this link." });
  } catch (error) {
    showSafnexPopup(url, { error: true, errorMessage: error.message || "Unable to analyze this link." });
  } finally { isCheckingLink = false; }
}

function sendCheckRequest(url) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: "checkLink", url }, response => {
      if (chrome.runtime.lastError) return resolve({ success: false, error: chrome.runtime.lastError.message });
      resolve(response || { success: false, error: "No response from SAFNEX." });
    });
  });
}

function removePopup() { document.getElementById("safnex-popup-overlay")?.remove(); }
function visitSite(url) { removePopup(); window.location.assign(url); }
function openFullReport(url) { window.open(`${SAFNEX_REPORT_URL}?url=${encodeURIComponent(url)}`, "_blank", "noopener,noreferrer"); }

function showSafnexPopup(url, result) {
  removePopup();
  const overlay = document.createElement("div");
  overlay.id = "safnex-popup-overlay";
  overlay.className = "safnex-overlay";

  if (result.loading) {
    overlay.innerHTML = `<div class="safnex-popup"><div class="safnex-header"><div class="safnex-logo">🛡️ SAFNEX NOVA</div></div><div class="safnex-body"><div class="safnex-spinner"></div><h3>Checking Link Safety...</h3><p class="safnex-url">${escapeHtml(url)}</p><p class="safnex-check-text">SAFNEX NOVA is analyzing this link.</p></div></div>`;
  } else if (result.error) {
    overlay.innerHTML = `<div class="safnex-popup"><div class="safnex-header"><div class="safnex-logo">🛡️ SAFNEX NOVA</div><button type="button" class="safnex-close" data-action="close">✕</button></div><div class="safnex-body"><div class="safnex-icon safnex-warning">⚠️</div><h3>Could Not Check Link</h3><p class="safnex-verdict">${escapeHtml(result.errorMessage || "The SAFNEX server could not analyze this link.")}</p><p class="safnex-url">${escapeHtml(url)}</p><div class="safnex-actions"><button type="button" class="safnex-btn safnex-btn-secondary" data-action="close">Cancel</button><button type="button" class="safnex-btn safnex-btn-primary" data-action="visit">Visit Site</button></div><button type="button" class="safnex-full-report" data-action="report">View Full Report →</button></div></div>`;
  } else {
    const score = Math.max(0, Math.min(100, Math.round(Number(result.riskScore) || 0)));
    const riskLevel = String(result.riskLevel || "UNKNOWN").toUpperCase();
    const verdict = String(result.verdict || "Analysis completed.");
    const reasons = Array.isArray(result.reasons) ? result.reasons : [];
    const danger = riskLevel === "HIGH" || riskLevel === "CRITICAL";
    const warning = riskLevel === "MEDIUM" || riskLevel === "SUSPICIOUS";
    const icon = danger || warning ? "⚠️" : "✓";
    const iconClass = danger ? "safnex-danger" : warning ? "safnex-warning" : "safnex-safe";
    const reasonsHTML = reasons.length ? `<div class="safnex-reasons-title">Detection Details</div><ul class="safnex-reasons">${reasons.map(r => `<li>${escapeHtml(String(r))}</li>`).join("")}</ul>` : "";

    overlay.innerHTML = `<div class="safnex-popup"><div class="safnex-header"><div class="safnex-logo">🛡️ SAFNEX NOVA</div><button type="button" class="safnex-close" data-action="close">✕</button></div><div class="safnex-body"><div class="safnex-icon ${iconClass}">${icon}</div><h3>${escapeHtml(riskLevel)} RISK</h3><div class="safnex-score">Risk Score: <strong>${score}%</strong></div><p class="safnex-verdict">${escapeHtml(verdict)}</p><p class="safnex-url">${escapeHtml(url)}</p>${reasonsHTML}<div class="safnex-actions"><button type="button" class="safnex-btn safnex-btn-secondary" data-action="close">Cancel</button><button type="button" class="safnex-btn safnex-btn-primary" data-action="visit">Visit Site</button></div><button type="button" class="safnex-full-report" data-action="report">View Full Report →</button></div></div>`;
  }

  overlay.addEventListener("click", event => {
    const button = event.target.closest?.("[data-action]");
    if (!button) return;
    const action = button.dataset.action;
    if (action === "close") removePopup();
    if (action === "visit") visitSite(url);
    if (action === "report") openFullReport(url);
  });
  overlay.addEventListener("click", event => { if (event.target === overlay) removePopup(); });
  document.body.appendChild(overlay);
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}
