document.addEventListener("DOMContentLoaded", () => {
  const dashboardButton = document.getElementById("openDashboard");
  const settingsButton = document.getElementById("openSettings");

  dashboardButton?.addEventListener("click", () => {
    chrome.tabs.create({ url: "https://safnex-nova.onrender.com/home.html" });
  });

  settingsButton?.addEventListener("click", () => {
    chrome.tabs.create({ url: "chrome://extensions/?id=" + chrome.runtime.id });
  });
});
